package com.gamingroom;

/**
 * A base class to represent an entity in the gaming room application.
 */
public abstract class Entity {

    protected long id;
    protected String name;

    /**
     * Constructor with an identifier and name.
     */
    protected Entity(long id, String name) {
        this.id = id;
        this.name = name;
    }

    /**
     * @return the id of the entity.
     */
    public long getId() {
        return id;
    }

    /**
     * @return the name of the entity.
     */
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Entity [id=" + id + ", name=" + name + "]";
    }
}

