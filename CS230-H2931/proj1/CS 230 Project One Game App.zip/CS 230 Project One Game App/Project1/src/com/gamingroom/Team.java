package com.gamingroom;

import java.util.List;
import java.util.ArrayList;

/**
 * A class to hold information about a team.
 * Inherits from Entity class.
 */
public class Team extends Entity {

    // A list to keep track of players
    private List<Player> players = new ArrayList<Player>();

    /**
     * Constructor with an identifier and name.
     *
     * @param id   The unique identifier for this team.
     * @param name The name of this team.
     */
    public Team(long id, String name) {
        super(id, name); // Call to Entity's constructor
    }

    /**
     * Method to add a player to the team. It checks for uniqueness of the player name.
     *
     * @param name The name of the player to add.
     * @return The player added to the team, or the existing player if the name is not unique.
     */
    public Player addPlayer(String name) {
        // Check if the player already exists based on the name
        for (Player player : players) {
            if (player.getName().equalsIgnoreCase(name)) {
                // Return the existing player if found
                return player;
            }
        }
        // If player name is unique, create and add to the team
        Player newPlayer = new Player(GameService.getInstance().getNextPlayerId(), name);
        players.add(newPlayer);
        return newPlayer;
    }

    /**
     * Getter for the players list.
     *
     * @return A copy of the list of players to prevent direct modification.
     */
    public List<Player> getPlayers() {
        return new ArrayList<Player>(players);
    }

    /**
     * Returns a string representation of the team.
     *
     * @return A string representing the team.
     */
    @Override
    public String toString() {
        return "Team [id=" + getId() + ", name=" + getName() + ", players=" + players + "]";
    }

    // Depending on your UML diagram and project requirements, you may need to add more methods here.
}
