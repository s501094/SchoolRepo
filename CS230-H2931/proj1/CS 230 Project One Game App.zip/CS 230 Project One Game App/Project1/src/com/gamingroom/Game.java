package com.gamingroom;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * A class to hold information about a game
 * Inherits from Entity class
 */
public class Game extends Entity {

    // A list to keep track of teams within the game
    private List<Team> teams = new ArrayList<Team>();

    // Constructor that accepts id and name
    public Game(long id, String name) {
        super(id, name); // Call to Entity's constructor
    }

    // Method to add a team using iterator pattern for uniqueness check
    public Team addTeam(String name) {
        Iterator<Team> iterator = teams.iterator();
        while (iterator.hasNext()) {
            Team team = iterator.next();
            if (team.getName().equalsIgnoreCase(name)) {
                return team; // Return existing team if name matches
            }
        }
        // Create new team if name is unique
        Team newTeam = new Team(GameService.getInstance().getNextTeamId(), name);
        teams.add(newTeam);
        return newTeam;
    }

    // Getter for teams
    public List<Team> getTeams() {
        return new ArrayList<Team>(teams); // Return a copy of the teams list
    }

    @Override
    public String toString() {
        return "Game [id=" + getId() + ", name=" + getName() + ", teams=" + teams + "]";
    }
    
    // The rest of your Game class code...
}
