package com.gamingroom;

/**
 * A class to test a singleton's behavior.
 */
public class SingletonTester {

    /**
     * Tests the singleton to ensure only one instance exists.
     */
    public void testSingleton() {
        
        System.out.println("\nAbout to test the singleton...");
        
        // Obtain local reference to the singleton instance of GameService
        GameService service = GameService.getInstance();
        
        // Try to add a game to test the singleton's functionality
        Game testGame = service.addGame("Test Game");
        System.out.println(testGame);
        
        // Print out all games to verify singleton instance
        for (int i = 0; i < service.getGameCount(); i++) {
            System.out.println(service.getGame(i));
        }
    }
}
