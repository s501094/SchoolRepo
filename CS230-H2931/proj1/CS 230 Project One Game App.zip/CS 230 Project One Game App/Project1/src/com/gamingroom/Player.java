package com.gamingroom;

/**
 * A class to hold information about a player.
 * Inherits from the Entity class.
 */
public class Player extends Entity {

    /**
     * Constructor with an identifier and name.
     *
     * @param id   The unique identifier for this player.
     * @param name The name of this player.
     */
    public Player(long id, String name) {
        super(id, name); // Call to Entity's constructor to initialize id and name.
    }

    /**
     * Returns a string representation of the player.
     *
     * @return A string representing the player.
     */
    @Override
    public String toString() {
        return "Player [id=" + getId() + ", name=" + getName() + "]";
    }

    // Depending on your UML diagram and project requirements, you may need to add more methods here.
}
