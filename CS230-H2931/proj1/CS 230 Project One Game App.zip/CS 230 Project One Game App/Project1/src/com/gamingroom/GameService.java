package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A singleton service for the game engine
 */
public class GameService {

    // Static variables for unique identifiers
    private long nextGameId = 1;
    private long nextTeamId = 1;
    private long nextPlayerId = 1;

    // A list of the active games
    private List<Game> games = new ArrayList<Game>();

    // Single instance of GameService
    private static GameService instance = new GameService();

    // Private constructor so no instances can be made outside this class
    private GameService() {}

    // Public method to return the single instance of the class
    public static GameService getInstance() {
        return instance;
    }

    // Add game method with iterator pattern for uniqueness check
    public Game addGame(String name) {
        for (Game game : games) {
            if (game.getName().equalsIgnoreCase(name)) {
                return game; // Return existing game if name matches
            }
        }
        // Create new game if name is unique
        Game newGame = new Game(nextGameId++, name);
        games.add(newGame);
        return newGame;
    }

    // Returns the game instance at the specified index.
    public Game getGame(int index) {
        if (index >= 0 && index < games.size()) {
            return games.get(index);
        }
        return null; // or throw an exception if index is out of bounds
    }

    // Returns the game instance with the specified name.
    public Game getGame(String name) {
        for (Game game : games) {
            if (game.getName().equalsIgnoreCase(name)) {
                return game;
            }
        }
        return null; // or indicate that the game was not found
    }

    // Returns the game instance with the specified id.
    public Game getGame(long id) {
        for (Game game : games) {
            if (game.getId() == id) {
                return game;
            }
        }
        return null; // or indicate that the game was not found
    }

    // Returns the number of games currently active
    public int getGameCount() {
        return games.size();
    }

    // Method to get the next available team ID
    public long getNextTeamId() {
        return nextTeamId++;
    }

    // Method to get the next available player ID
    public long getNextPlayerId() {
        return nextPlayerId++;
    }

    // Additional methods to add teams and players will be similar to addGame
    // Ensure to implement them based on your UML diagram and project requirements
    
    // Rest of your GameService class code...
}
